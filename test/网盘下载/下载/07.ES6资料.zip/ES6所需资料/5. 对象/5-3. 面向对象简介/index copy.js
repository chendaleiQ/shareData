//1. 冰箱门打开
function openFrige(){

}
openFrige();

//2. 大象装进去
function elephantIn(){

}

elephantIn();

//3. 冰箱门关上
function closeFrige(){

}

closeFrige();