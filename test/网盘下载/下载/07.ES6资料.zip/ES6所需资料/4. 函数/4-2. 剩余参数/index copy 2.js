function test(...args1, ...args2) {
    console.log(args1)
    console.log(args2)
}

test(1, 32, 46, 7, 34);