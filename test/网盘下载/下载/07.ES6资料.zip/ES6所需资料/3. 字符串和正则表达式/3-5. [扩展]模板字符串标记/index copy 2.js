var text = String.raw`abc\t\nbcd`;

console.log(text);